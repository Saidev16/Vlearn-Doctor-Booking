<?php
/*----------------------------------------------------------------------
# Designed by: JML
------------------------------------------------------------------------*/
defined( '_JEXEC' ) or die( 'Restricted index access' );


//START COLLAPSING THAT MODULE:)
$left = $this->countModules( 'left' );
$right = $this->countModules( 'right' );
if ( $left  &&  $right  ) {
	$content  = 'content';
	$left  = 'left';
	$right = 'right';
	$mainbody  = 'mainbody';
	$wrap    = 'wrap';
    $insidewrap='insidewrap';
	$landrwrap='landrwrap';
	}elseif ( $left) {
	$content  = 'content_L';
	$left  = 'left_L';
	$mainbody  = 'mainbody_L';
	$wrap    = 'wrapblank';
	$insidewrap='insidewrapblank';
	}elseif ( $right) {
	$content  = 'content_R';
	$right = 'right_R';
	$mainbody  = 'mainbody_R';
	$wrap    = 'wrap';
	$insidewrap='insidewrapblank';
	$landrwrap='landrwrap_R';
	} else {
	$content = 'content_R';
	$mainbody  = 'mainbody_L';
	$wrap    = 'wrapblank';
	$landrwrap='landrwrap';
	$insidewrap='insidewrapblank';
	}




//START COLLAPSING TOP:)
$top = 0;
if ($this->countModules('user1')) $top++;
if ($this->countModules('user2')) $top++;
if ($this->countModules('user3')) $top++;
if ($this->countModules('user4')) $top++;
if ($top == 4) {
	$topwidth = '23.5%';
}elseif ($top == 3) {
	$topwidth = '31.9%';
} else if ($top == 2) {
	$topwidth = '48%';		
} else if ($top == 1) {
	$topwidth = '98%';
}
//START COLLAPSING BOTTOM:)
$bottom = 0;
if ($this->countModules('user5')) $bottom++;
if ($this->countModules('user6')) $bottom++;
if ($this->countModules('user7')) $bottom++;
if ($bottom == 3) {
	$bottomwidth = '33.3%';
} else if ($bottom == 2) {
	$bottomwidth = '50%';		
} else if ($bottom == 1) {
	$bottomwidth = '100%';
}
//img
$bgimg = 0;
if ($this->countModules('right')) $bgimg++;
if ( $bgimg > 0 ) {
$prazno ='prazno-0';
$sjena1='sjena1';
	} else if ($bgimg < 1) {
	$prazno = 'prazno-1';
	$sjena1='sjena2';
	}

?>