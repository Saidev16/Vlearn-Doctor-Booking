<?php
/*----------------------------------------------------------------------
# JML 
# ----------------------------------------------------------------------
# Designed by: JML
# License: GNU, GPL
------------------------------------------------------------------------*/
defined( '_JEXEC' ) or die( 'Restricted index access' );


// SUCKERFISH  MENU SWITCH // 
$menu_name = $this->params->get("menuName", "mainmenu");// mainmenu by default, can be any Joomla! menu name




$default_font  = $this->params->get("fontsize", "medium"); // SMALL | MEDIUM | BIG
$default_width = $this->params->get("sitewidth", "wide"); // WIDE | NARROW 

$showtools  = $this->params->get("templateTools", "1"); // 0 HIDE TOOLS | 1 SHOW ALL  | 2 COLOR AND WIDTH  | 3 COLOR AND FONT | 4 WIDTH AND FONT |5 WIDTH ONLY | 6 FONT ONLY | 7 COLOR ONLY

// SEO SECTION //

$seo                    = $this->params->get ("seo", "Joomla Software solutions Template");                      # JUST FOLOW THE TEXT
$tags                   = $this->params->get ("tags", "Joomla Software, Joomla Templates, Youjoomla");                        # JUST FOLOW THE TEXT

#DO NOT EDIT BELOW THIS LINE
define( 'TEMPLATEPATH', dirname(__FILE__) );
include( TEMPLATEPATH.DS."settings.php");
include( TEMPLATEPATH.DS."styleswitcher.php");
require( TEMPLATEPATH.DS."suckerfish.php");

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" >
<head>
<jdoc:include type="head" />


<link rel="shortcut icon" href="<?php echo $mosConfig_live_site;?>/images/favicon.ico" />
<link href="templates/<?php echo $this->template ?>/css/template_css.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="templates/<?php echo $this->template ?>/src/mootools.v1.1.js"></script>
<script type="text/javascript" src="templates/<?php echo $this->template ?>/src/sve.js"></script>
<!--[if lte IE 7]>
<script type="text/javascript" src="templates/<?php echo $this->template ?>/src/ie2.js"></script><![endif]-->
<!--[if lte IE 6]>
<style type="text/css">
img,li,#search,#logo{
	behavior: url(templates/<?php echo $this->template ?>/css/iepngfix.htc);
}
#images_slide img{
	behavior:none;
}
#search .inputbox{
margin-top:0px;

}
</style>
<![endif]-->


</head>
<!-- ODVAJANJE ZAREZOM -->
<body>
<div id="hdbg">
<div id="topwrap" style="font-size:<?php echo $css_font; ?>; width:<?php echo $css_width; ?>;"><!-- topwrap-->
<!-- start header-->
<div id="header"> 
<div id="headrer">
<div id="logo"><div id="tags"> <h1><a href="index.php" title="<?php echo $tags?>"><?php echo $seo ?></a></h1></div>
</div>
<?php if ($this->countModules('header')) { ?>
<div id="search"><jdoc:include type="modules" name="header" style="raw" />
</div><?php } ?>
</div>
</div><!-- end header-->


</div><!-- end topwrap-->
<!-- suckerfish-->
<div id="suck" style="font-size:<?php echo $css_font; ?>;">
<div style="font-size:<?php echo $css_font; ?>; width:<?php echo $css_width; ?>; margin:0 auto; text-align:center; ">

<div id="navigacija">
<?php mosShowListMenu($menu_name); ?>
</div>
</div>
</div>
<!-- end suckerfish-->

<!-- midwrap-->
<?php if ($this->countModules('user1') || $this->countModules('user2') || $this->countModules('user3') || $this->countModules('user4')) { ?>
<div id="midwrap">
<div style="font-size:<?php echo $css_font; ?>; width:<?php echo $css_width; ?>; margin:0 auto; text-align:center; padding:10px;">
<?php if ($this->countModules('user1')) { ?>
<div id="user1" style="width:<?php echo $topwidth; ?>;"><jdoc:include type="modules" name="user1" style="xhtml" /></div><?php } ?>
<?php if ($this->countModules('user2')) { ?>
<div id="user2" style="width:<?php echo $topwidth; ?>;"><jdoc:include type="modules" name="user2" style="xhtml" /></div><?php } ?>
<?php if ($this->countModules('user3')) { ?>
<div id="user3" style="width:<?php echo $topwidth; ?>;"><jdoc:include type="modules" name="user3" style="xhtml" /></div><?php } ?>
<?php if ($this->countModules('user4')) { ?>
<div id="user4" style="width:<?php echo $topwidth; ?>;"><jdoc:include type="modules" name="user4" style="xhtml" /></div><?php } ?>
</div></div><?php } ?>
<!--end midwrap-->
<!--pathway-->
<div id="pathway" >
<div id="path" style="font-size:<?php echo $css_font; ?>; width:<?php echo $css_width; ?>;">
<div id="path1">
<jdoc:include type="module" name="breadcrumbs" style="none" />
</div>
<div id="tools"><? include ("templates/".$this->template ."/tools.php");?>
</div>
</div>
</div>
<!--end pathway-->
<div id="<?php echo $kontejner ?>">
<div  id="<?php echo $prazno ?>">
<div id="<?php echo $sjena1 ?>">
<div id="<?php echo $centar ?>" style="font-size:<?php echo $css_font; ?>; width:<?php echo $css_width; ?>;">
<div id="<?php echo $sjena ?>">
<div id="<?php echo $wrap?>">
<div id="<?php echo $insidewrap ?>">
<div id="<?php echo $mainbody ?>">
<div id="<?php echo $content ?>">
<div class="inside">
<div id="newsflash">
<jdoc:include type="modules" name="top" style="xhtml" />
</div>
<jdoc:include type="component" /> 

</div></div>
<?php if ($this->countModules('left')) { ?>
<div id="<?php echo $left ?>"> 
<div class="inside"><!-- keep mods of edges-->
<jdoc:include type="modules" name="left" style="xhtml" />
<!-- end inside--></div><!-- end modsl--></div><!-- end left side-->
<?php } ?>
</div> <!--end of main-body-->
<!-- right side always stand alone-->
<?php if ($this->countModules('right')) { ?>
<div id="<?php echo $right ?>"> 
<div class="inside"> <!-- keep mods of edges-->
<jdoc:include type="modules" name="right" style="xhtml" />
</div><!-- end of inside --></div><!-- end right side-->
<?php } ?>
<div id="clr"><div id="footer1"><a href=http://partnerstvo.ru/>.</a></div></div>

</div><!-- end of insidewrap--></div> <!--end of wrap-->
</div><!-- end centar-->
</div>
</div>
</div>
</div>
<!-- bottmods-->
<?php if ($this->countModules('user5') || $this->countModules('user6') || $this->countModules('user7')) { ?>
<div id="bottmods">
<div style="font-size:<?php echo $css_font; ?>; width:<?php echo $css_width; ?>; margin:0 auto; text-align:center; padding:10px;">
<?php if ($this->countModules('user5')) { ?>
<div id="user5" style="width:<?php echo $bottomwidth; ?>;"><jdoc:include type="modules" name="user5" style="xhtml" /></div><?php } ?>
<?php if ($this->countModules('user6')) { ?>
<div id="user6" style="width:<?php echo $bottomwidth; ?>;"><jdoc:include type="modules" name="user6" style="xhtml" /></div><?php } ?>
<?php if ($this->countModules('user7')) { ?>
<div id="user7" style="width:<?php echo $bottomwidth; ?>;"><jdoc:include type="modules" name="user7" style="xhtml" /></div><?php } ?>
</div></div>
<!--end bottmods-->
<?php } ?>
<div id="footer">
<div id="footin">Powered by 
<a href="http://joomla.com">Joomla!</a> | 
<a href="index.php?option=com_rss&amp;feed=RSS2.0&amp;no_html=1" target="_blank">RSS</a>
</div>
</div>
</div>









































<div id="footer1">Design: <a href=http://partnerstvo.ru/lib/pravo>Pravo</a> & <a href=http://printstyle.ru>Printstyle</a> & <a href=http://partnerstvo.ru/lib/kontr/>Contracts</a> & <a href=http://madhead.ru>Aerography</a>.</div></body></html>