window.addEvent('domready', function(){


<!--smoth scroll-->
new SmoothScroll({duration: 1000});	
<!--end sm scroll-->

		

});

