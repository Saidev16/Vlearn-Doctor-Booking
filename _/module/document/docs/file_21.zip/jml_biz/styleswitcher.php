<?php

defined( '_JEXEC' ) or die( 'Restricted index access' );

if(!isset($_SESSION)) 
{ 
session_start(); 
}


//
//function style_switcher() {
//while(list($key, $val) = each($mystyles)){
// echo "<a href='".$_SERVER['PHP_SELF']."?change_css=".$key."' title='".$val["label"]."'>".$val["label"]."</a>";
//}
//}
//FONT SWITCH

$myfont = array();


$myfont['small']['file'] = "9px";
$myfont['medium']['file'] = "12px";
$myfont['large']['file'] = "16px"; // default

$myfont['small']['label'] = '<img src="templates/'.$this->template.'/images/small.gif" alt="Small" title="Small" />&nbsp;';
$myfont['medium']['label'] = '<img src="templates/'.$this->template.'/images/medium.gif" alt="Medium" title="Medium" />&nbsp;';

$myfont['large']['label'] = '<img src="templates/'.$this->template.'/images/large.gif" alt="Large" title="Large" />&nbsp;';




if (isset($_GET['change_font']) && $_GET['change_font'] != "") {
    $_SESSION['font'] = $_GET['change_font'];
} else {
    $_SESSION['font'] = (!isset($_SESSION['font'])) ? $default_font : $_SESSION['font'];
}
switch ($_SESSION['font']) {
    case "small":
    $css_font = "9px";
    break;
    case "medium":
    $css_font = "12px";
    break;
	case "large":
    $css_font = "16px";
    break;
    default:
    $css_font = "12px";
}

//WIDTH SWITCH


$mywidth = array();


$mywidth['wide']['file'] = "1000px";
$mywidth['narrow']['file'] = "776px";

$mywidth['wide']['label'] = '<img src="templates/'.$this->template.'/images/wide.gif" alt="Wide" title="Wide" />&nbsp;';
$mywidth['narrow']['label'] = '<img src="templates/'.$this->template.'/images/narrow.gif" alt="Narrow" title="Narrow" />&nbsp;'; 




if (isset($_GET['change_width']) && $_GET['change_width'] != "") {
    $_SESSION['width'] = $_GET['change_width'];
} else {
    $_SESSION['width'] = (!isset($_SESSION['width'])) ? $default_width : $_SESSION['width'];
}
switch ($_SESSION['width']) {
    case "wide":
    $css_width = "1000px";
	$kontejner ='kontejner-w';
	$centar ='centar-w';
	$sjena ='sjena-w';
    break;
    case "narrow":
    $css_width = "776px";
	$kontejner ='kontejner-n';
	$centar ='centar-n';
	$sjena ='sjena-n';
    break;
    default:
    $css_width = "1000px";
}


?>