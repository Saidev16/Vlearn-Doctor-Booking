<?php
/**
 * @copyright	Copyright (C) 2008 JoomaShob.be Club. All rights reserved.
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
defined( '_JEXEC' ) or die( 'Restricted access' );
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; <?php echo _ISO; ?>" />
<link href="<?php echo $this->baseurl ?>/templates/mitra_blue/css/template_css.css" rel="stylesheet" type="text/css" />
<jdoc:include type="head" />
</head>

<body>

<div align="center">
	<table border="0" cellpadding="0" cellspacing="0" width="940" id="table1">
		<tr>
			<td>
			<table border="0" cellpadding="0" cellspacing="0" width="100%" id="table2">
				<tr>
					<td width="391">
					<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/right_logo.png"></td>
					<td style="background-image: url('<?php echo $this->baseurl ?>/templates/mitra_blue/images/bac_logo.png'); background-repeat: no-repeat; background-position: left top">
					<div align="center"><jdoc:include type="modules" name="footer" /></div></td>
					<td width="76">
					<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/left_logo.png"></td>
				</tr>
			</table>
			</td>
		</tr>
		<tr>
			<td>
			<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/spacer.png" width="3" height="3"></td>
		</tr>
		<tr>
			<td>
			<table border="0" cellpadding="0" cellspacing="0" width="100%" id="table3">
				<tr>
					<td width="8">
					<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/right_search.png"></td>
					<td style="background-image: url('<?php echo $this->baseurl ?>/templates/mitra_blue/images/bac_search.png'); background-repeat: repeat-x; background-position: left top" width="200">
					<jdoc:include type="modules" name="user4" /></td>
					<td width="55">
					<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/right_top_link.png"></td>
					<td style="background-image: url('<?php echo $this->baseurl ?>/templates/mitra_blue/images/bac_top_link.png'); background-repeat: repeat-x; background-position: left top">
					<jdoc:include type="modules" name="user3" /></td>
					<td width="17">
					<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/left_top_link.png"></td>
				</tr>
			</table>
			</td>
		</tr>
		<tr>
			<td>
			<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/spacer.png" width="3" height="3"></td>
		</tr>
		<tr>
			<td>
			<div align="center">
				<table border="0" cellpadding="0" cellspacing="0" width="100%" id="table4">
					<tr>
						<td width="191" valign="top">
						<table border="0" cellpadding="0" cellspacing="0" width="100%" id="table12">
							<tr>
								<td>
						<div align="center">
							<table border="0" cellpadding="0" cellspacing="0" width="100%" id="table13">
												<tr>
													<td width="7">
													<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/top_right.png" alt="Mitra Global CMS" /></td>
													<td style="background-image: url('<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/top.png'); background-repeat: repeat-x; background-position: left top">
													<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/top.png" alt="Mitra Global CMS" /></td>
													<td width="6">
													<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/top_left.png" alt="Mitra Global CMS" /></td>
												</tr>
												<tr>
													<td width="7" style="background-image: url('<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/right.png'); background-repeat: repeat-y; background-position: right top">&nbsp;</td>
													<td style="height: 130px; background-color:#FFFFFF" valign="top">
													<jdoc:include type="modules" name="left" style="rounded"/></td>
													<td width="6" style="background-image: url('<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/left.png'); background-repeat: repeat-y; background-position: left top">&nbsp;</td>
												</tr>
												<tr>
													<td width="7">
													<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/bot_right.png" alt="Mitra Global CMS" /></td>
													<td style="background-image: url('<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/bot.png'); background-repeat: repeat-x; background-position: right bottom">
													<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/bot.png" alt="Mitra Global CMS" /></td>
													<td width="6">
													<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/bot_left.png" alt="Mitra Global CMS" /></td>
												</tr>
											</table>
						</div>
								</td>
							</tr>
							<tr>
								<td>123</td>
							</tr>
						</table>
						</td>
						<td width="3" valign="top"></td>
						<td valign="top">
						<table border="0" cellpadding="0" cellspacing="0" width="100%" id="table7">
<?php if($this->countModules('user1')) : ?>							<tr>
								<td>
								<table border="0" cellpadding="0" cellspacing="0" width="100%" id="table8">
									<tr>
<?php if($this->countModules('user1')) : ?>										<td width="49%" valign="top">
										<table border="0" cellpadding="0" cellspacing="0" width="99%">
												<tr>
													<td width="7">
													<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/top_right.png" alt="Mitra Global CMS" /></td>
													<td style="background-image: url('<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/top.png'); background-repeat: repeat-x; background-position: left top">
													<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/top.png" alt="Mitra Global CMS" /></td>
													<td width="6">
													<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/top_left.png" alt="Mitra Global CMS" /></td>
												</tr>
												<tr>
													<td width="7" style="background-image: url('<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/right.png'); background-repeat: repeat-y; background-position: right top">&nbsp;</td>
													<td style="height: 130px; background-color:#FFFFFF" valign="top">
													<jdoc:include type="modules" name="user1" style="rounded"/></td>
													<td width="6" style="background-image: url('<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/left.png'); background-repeat: repeat-y; background-position: left top">&nbsp;</td>
												</tr>
												<tr>
													<td width="7">
													<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/bot_right.png" alt="Mitra Global CMS" /></td>
													<td style="background-image: url('<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/bot.png'); background-repeat: repeat-x; background-position: right bottom">
													<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/bot.png" alt="Mitra Global CMS" /></td>
													<td width="6">
													<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/bot_left.png" alt="Mitra Global CMS" /></td>
												</tr>
											</table></td>
<?php endif; ?>
<?php if($this->countModules('user2')) : ?>										<td width="5" valign="top">

										<td valign="top">
										<table border="0" cellpadding="0" cellspacing="0" width="100%" id="table9">
												<tr>
													<td width="7">
													<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/top_right.png" alt="Mitra Global CMS" /></td>
													<td style="background-image: url('<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/top.png'); background-repeat: repeat-x; background-position: left top">
													<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/top.png" alt="Mitra Global CMS" /></td>
													<td width="6">
													<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/top_left.png" alt="Mitra Global CMS" /></td>
												</tr>
												<tr>
													<td width="7" style="background-image: url('<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/right.png'); background-repeat: repeat-y; background-position: right top">&nbsp;</td>
													<td style="height: 130px; background-color:#FFFFFF" valign="top">
													<jdoc:include type="modules" name="user2" style="rounded"/></td>
													<td width="6" style="background-image: url('<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/left.png'); background-repeat: repeat-y; background-position: left top">&nbsp;</td>
												</tr>
												<tr>
													<td width="7">
													<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/bot_right.png" alt="Mitra Global CMS" /></td>
													<td style="background-image: url('<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/bot.png'); background-repeat: repeat-x; background-position: right bottom">
													<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/bot.png" alt="Mitra Global CMS" /></td>
													<td width="6">
													<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/bot_left.png" alt="Mitra Global CMS" /></td>
												</tr>
											</table></td>
<?php endif; ?>
									</tr>
								</table>
								</td>
							</tr>
<?php endif; ?>
							<tr>
								<td>
			<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/spacer.png" width="3" height="3"></td>
							</tr>
							<tr>
								<td>
								<table border="0" cellpadding="0" cellspacing="0" width="100%" id="table10">
												<tr>
													<td width="7">
													<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/top_right.png" alt="Mitra Global CMS" /></td>
													<td style="background-image: url('<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/top.png'); background-repeat: repeat-x; background-position: left top">
													<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/top.png" alt="Mitra Global CMS" /></td>
													<td width="6">
													<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/top_left.png" alt="Mitra Global CMS" /></td>
												</tr>
												<tr>
													<td width="7" style="background-image: url('<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/right.png'); background-repeat: repeat-y; background-position: right top">&nbsp;</td>
													<td style="height: 630px; background-color:#FFFFFF" valign="top">
													<jdoc:include type="component" /></td>
													<td width="6" style="background-image: url('<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/left.png'); background-repeat: repeat-y; background-position: left top">&nbsp;</td>
												</tr>
												<tr>
													<td width="7">
													<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/bot_right.png" alt="Mitra Global CMS" /></td>
													<td style="background-image: url('<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/bot.png'); background-repeat: repeat-x; background-position: right bottom">
													<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/bot.png" alt="Mitra Global CMS" /></td>
													<td width="6">
													<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/bot_left.png" alt="Mitra Global CMS" /></td>
												</tr>
											</table></td>
							</tr>
						</table>
						</td>
						<td width="3" valign="top"></td>
<?php if($this->countModules('right')) : ?>						<td width="191" valign="top">
						<table border="0" cellpadding="0" cellspacing="0" width="100%" id="table14">
							<tr>
								<td>
						<div align="center">
<table border="0" cellpadding="0" cellspacing="0" width="100%" id="table15">
												<tr>
													<td width="7">
													<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/top_right.png" alt="Mitra Global CMS" /></td>
													<td style="background-image: url('<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/top.png'); background-repeat: repeat-x; background-position: left top">
													<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/top.png" alt="Mitra Global CMS" /></td>
													<td width="6">
													<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/top_left.png" alt="Mitra Global CMS" /></td>
												</tr>
												<tr>
													<td width="7" style="background-image: url('<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/right.png'); background-repeat: repeat-y; background-position: right top">&nbsp;</td>
													<td style="height: 130px; background-color:#FFFFFF" valign="top">
													<jdoc:include type="modules" name="right" style="rounded"/></td>
													<td width="6" style="background-image: url('<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/left.png'); background-repeat: repeat-y; background-position: left top">&nbsp;</td>
												</tr>
												<tr>
													<td width="7">
													<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/bot_right.png" alt="Mitra Global CMS" /></td>
													<td style="background-image: url('<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/bot.png'); background-repeat: repeat-x; background-position: right bottom">
													<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/bot.png" alt="Mitra Global CMS" /></td>
													<td width="6">
													<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/box/bot_left.png" alt="Mitra Global CMS" /></td>
												</tr>
											</table>
						</div>
								</td>
							</tr>
							<tr>
								<td>123</td>
							</tr>
						</table>
						</td>
<?php endif; ?>					</tr>
				</table>
			</div>
			</td>
		</tr>
		<tr>
			<td>
			<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/spacer.png" width="3" height="3"></td>
		</tr>
		<tr>
			<td>
			<table border="0" cellpadding="0" cellspacing="0" width="100%" id="table11" style="background-image: url('<?php echo $this->baseurl ?>/templates/mitra_blue/images/bac_footer.png'); background-repeat: repeat-x; background-position: left top">
				<tr>
					<td width="111">
					<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/right_footer.png"></td>
					<td id="footer">
					<jdoc:include type="modules" name="syndicate" />
					<br/><?php echo JText::_('Powered by') ?> <a href="http://www.joomla.org">Joomla!</a>.
						Design: <a href="http://www.joomlashop.be">JoomlaShop.Be</a>.</td>
					<td width="111">
					<img border="0" src="<?php echo $this->baseurl ?>/templates/mitra_blue/images/left_footer.png"></td>
				</tr>
			</table>
			</td>
		</tr>
	</table>
</div>
<jdoc:include type="modules" name="debug" />
</body>

</html>